import { 
  users, type User, type InsertUser,
  subscriptions, type Subscription, type InsertSubscription,
  transactions, type Transaction, type InsertTransaction
} from "@shared/schema";
import { drizzle } from 'drizzle-orm/postgres-js';
import { eq } from 'drizzle-orm/expressions';
import postgres from 'postgres';
import type { PostgresJsDatabase } from 'drizzle-orm/postgres-js';

// Storage interface with CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPremiumStatus(id: number, isPremium: boolean): Promise<User | undefined>;
  updateUserStripeInfo(id: number, stripeInfo: { 
    stripeCustomerId?: string, 
    stripeSubscriptionId?: string 
  }): Promise<User | undefined>;

  // Subscription methods
  getSubscriptionsByUserId(userId: number): Promise<Subscription[]>;
  getSubscription(id: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(
    id: number, 
    updates: Partial<Omit<InsertSubscription, "userId">>
  ): Promise<Subscription | undefined>;
  deleteSubscription(id: number): Promise<boolean>;

  // Transaction methods
  getTransactionsByUserId(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  createTransactions(transactions: InsertTransaction[]): Promise<Transaction[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subscriptions: Map<number, Subscription>;
  private transactions: Map<number, Transaction>;
  userCurrentId: number;
  subscriptionCurrentId: number;
  transactionCurrentId: number;

  constructor() {
    this.users = new Map();
    this.subscriptions = new Map();
    this.transactions = new Map();
    this.userCurrentId = 1;
    this.subscriptionCurrentId = 1;
    this.transactionCurrentId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      isPremium: false, 
      stripeCustomerId: null, 
      stripeSubscriptionId: null,
      email: insertUser.email || null  // Ensure email is string | null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPremiumStatus(id: number, isPremium: boolean): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, isPremium };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserStripeInfo(
    id: number, 
    stripeInfo: { stripeCustomerId?: string, stripeSubscriptionId?: string }
  ): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      stripeCustomerId: stripeInfo.stripeCustomerId || user.stripeCustomerId,
      stripeSubscriptionId: stripeInfo.stripeSubscriptionId || user.stripeSubscriptionId
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Subscription methods
  async getSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values()).filter(
      (subscription) => subscription.userId === userId
    );
  }

  async getSubscription(id: number): Promise<Subscription | undefined> {
    return this.subscriptions.get(id);
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const id = this.subscriptionCurrentId++;
    // Ensure all required properties are present with correct types
    const subscription: Subscription = { 
      ...insertSubscription, 
      id,
      // Ensure these properties are not undefined
      status: insertSubscription.status || null,
      frequency: insertSubscription.frequency || null,
      lastPayment: insertSubscription.lastPayment || null,
      nextPayment: insertSubscription.nextPayment || null,
      isStillUsing: insertSubscription.isStillUsing || null,
      logo: insertSubscription.logo || null
    };
    this.subscriptions.set(id, subscription);
    return subscription;
  }

  async updateSubscription(
    id: number, 
    updates: Partial<Omit<InsertSubscription, "userId">>
  ): Promise<Subscription | undefined> {
    const subscription = await this.getSubscription(id);
    if (!subscription) return undefined;
    
    const updatedSubscription = { ...subscription, ...updates };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }

  async deleteSubscription(id: number): Promise<boolean> {
    return this.subscriptions.delete(id);
  }

  // Transaction methods
  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId
    );
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionCurrentId++;
    const transaction: Transaction = { 
      ...insertTransaction, 
      id,
      // Ensure data is never undefined
      data: insertTransaction.data || {}
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async createTransactions(insertTransactions: InsertTransaction[]): Promise<Transaction[]> {
    return Promise.all(
      insertTransactions.map((transaction) => this.createTransaction(transaction))
    );
  }
}

// PostgreSQL storage implementation
export class PostgresStorage implements IStorage {
  private db: PostgresJsDatabase;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("Missing DATABASE_URL environment variable");
    }
    
    const client = postgres(process.env.DATABASE_URL);
    this.db = drizzle(client);
    
    console.log("PostgreSQL database connection established");
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return this.db.select().from(users);
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUserPremiumStatus(id: number, isPremium: boolean): Promise<User | undefined> {
    const result = await this.db
      .update(users)
      .set({ isPremium })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async updateUserStripeInfo(
    id: number,
    stripeInfo: { stripeCustomerId?: string; stripeSubscriptionId?: string }
  ): Promise<User | undefined> {
    const result = await this.db
      .update(users)
      .set(stripeInfo)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Subscription methods
  async getSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return this.db.select().from(subscriptions).where(eq(subscriptions.userId, userId));
  }

  async getSubscription(id: number): Promise<Subscription | undefined> {
    const result = await this.db.select().from(subscriptions).where(eq(subscriptions.id, id));
    return result[0];
  }

  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const result = await this.db.insert(subscriptions).values(subscription).returning();
    return result[0];
  }

  async updateSubscription(
    id: number,
    updates: Partial<Omit<InsertSubscription, "userId">>
  ): Promise<Subscription | undefined> {
    const result = await this.db
      .update(subscriptions)
      .set(updates)
      .where(eq(subscriptions.id, id))
      .returning();
    return result[0];
  }

  async deleteSubscription(id: number): Promise<boolean> {
    const result = await this.db.delete(subscriptions).where(eq(subscriptions.id, id));
    return !!result;
  }

  // Transaction methods
  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return this.db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const result = await this.db.insert(transactions).values(transaction).returning();
    return result[0];
  }

  async createTransactions(transactionList: InsertTransaction[]): Promise<Transaction[]> {
    const result = await this.db.insert(transactions).values(transactionList).returning();
    return result;
  }
}

// Check if we have a database URL, use PostgreSQL if available, otherwise fall back to in-memory
export const storage = process.env.DATABASE_URL ? new PostgresStorage() : new MemStorage();
