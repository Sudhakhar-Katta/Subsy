import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertSubscriptionSchema, 
  insertTransactionSchema 
} from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";
import passport from "passport";

// Initialize Stripe if API key exists
const stripeApiKey = process.env.STRIPE_SECRET_KEY || '';
const stripe = stripeApiKey ? new Stripe(stripeApiKey, { apiVersion: '2023-10-16' }) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      // Omit password from response
      const { password, ...userResponse } = user;
      
      res.status(201).json(userResponse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Authentication routes
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info.message || "Authentication failed" });
      }
      
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        
        return res.status(200).json(user);
      });
    })(req, res, next);
  });
  
  // User logout
  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });
  
  // Get the current user
  app.get("/api/current-user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    res.status(200).json(req.user);
  });

  // Subscriptions API
  app.get("/api/subscriptions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const subscriptions = await storage.getSubscriptionsByUserId(userId);
      res.status(200).json(subscriptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subscriptions" });
    }
  });

  app.post("/api/subscriptions", async (req, res) => {
    try {
      const subscriptionData = insertSubscriptionSchema.parse(req.body);
      const subscription = await storage.createSubscription(subscriptionData);
      res.status(201).json(subscription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid subscription data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create subscription" });
    }
  });

  app.patch("/api/subscriptions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid subscription ID" });
      }
      
      const subscription = await storage.getSubscription(id);
      
      if (!subscription) {
        return res.status(404).json({ message: "Subscription not found" });
      }
      
      const updates = req.body;
      const updatedSubscription = await storage.updateSubscription(id, updates);
      res.status(200).json(updatedSubscription);
    } catch (error) {
      res.status(500).json({ message: "Failed to update subscription" });
    }
  });

  // CSV Upload and Transaction Processing
  app.post("/api/upload-csv", async (req, res) => {
    try {
      const { userId, csvContent } = req.body;
      
      if (!userId || !csvContent) {
        return res.status(400).json({ message: "Invalid request data: userId and csvContent are required" });
      }
      
      // Parse CSV content to get transactions
      // Import the parser function dynamically since it's a client-side module
      const parseCSV = (csvString: string): any[] => {
        // Split the CSV into lines
        const lines = csvString.split(/\r?\n/).filter(line => line.trim() !== '');
        
        if (lines.length < 2) {
          throw new Error('CSV file must contain a header row and at least one data row');
        }
        
        // Extract the header row
        const rawHeaders = lines[0].split(',').map(header => header.trim().toLowerCase());
        
        // Enhanced header detection with fallbacks
        // For demo or testing purposes, generate minimal headers if needed
        const headers = rawHeaders.length >= 3 ? rawHeaders : ['date', 'description', 'amount'];
        
        // For testing: if we can't detect headers, treat all rows as data with assumed columns
        const isTestData = rawHeaders.length < 3;
        
        // Try to intelligently detect column positions
        let dateIndex = headers.findIndex(header => 
          header.includes('date') || header.includes('time') || header.includes('when')
        );
        
        let descriptionIndex = headers.findIndex(header => 
          header.includes('description') || header.includes('desc') || 
          header.includes('transaction') || header.includes('detail') ||
          header.includes('memo') || header.includes('narration') ||
          header.includes('note') || header.includes('particulars')
        );
        
        let amountIndex = headers.findIndex(header => 
          header.includes('amount') || header.includes('sum') || 
          header.includes('payment') || header.includes('debit') ||
          header.includes('credit') || header.includes('value') ||
          header.includes('price') || header.includes('fee')
        );
        
        // For demo data, use default positions if not found
        if (isTestData || dateIndex === -1) dateIndex = 0;
        if (isTestData || descriptionIndex === -1) descriptionIndex = 1;
        if (isTestData || amountIndex === -1) amountIndex = 2;
        
        console.log(`CSV parser detected columns: date=${dateIndex}, desc=${descriptionIndex}, amount=${amountIndex}`);
        
        
        // Parse data rows
        const transactions: any[] = [];
        
        for (let i = 1; i < lines.length; i++) {
          // Handle quoted fields that may contain commas
          const parsedLine = parseCSVLine(lines[i]);
          
          if (parsedLine.length <= Math.max(dateIndex, descriptionIndex, amountIndex)) {
            continue; // Skip rows that don't have enough fields
          }
          
          const date = parsedLine[dateIndex].trim();
          const description = parsedLine[descriptionIndex].trim();
          
          // Process amount: first clean it then ensure it's a valid number
          let rawAmount = parsedLine[amountIndex].trim();
          console.log(`CSV parser processing amount: ${rawAmount}`);
          
          // Clean the amount string and convert to number - keep negative signs for expenses
          let amount = rawAmount.replace(/[^\d.-]/g, ''); // Remove non-numeric chars except for - and .
          
          // Make sure it's a valid number
          if (amount && !isNaN(parseFloat(amount))) {
            // Amount is good
            console.log(`Processed amount: ${amount}`);
          } else {
            console.log(`Invalid amount found: ${rawAmount}, defaulting to 0`);
            amount = "0";
          }
          
          // Extract vendor name from description
          const vendor = extractVendorName(description);
          
          // Create an object with all columns as data
          const data: Record<string, string> = {};
          headers.forEach((header, index) => {
            if (index < parsedLine.length) {
              data[header] = parsedLine[index].trim();
            }
          });
          
          transactions.push({
            date,
            description,
            amount,
            vendor,
            data
          });
        }
        
        return transactions;
      };
      
      // Parse CSV line handling quoted fields
      const parseCSVLine = (line: string): string[] => {
        const result: string[] = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          
          if (char === '"') {
            // Toggle quote mode
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            // End of field
            result.push(current);
            current = '';
          } else {
            current += char;
          }
        }
        
        // Don't forget the last field
        result.push(current);
        
        return result;
      };
      
      // Extract vendor name from description
      const extractVendorName = (description: string): string => {
        // Common patterns in transaction descriptions
        const patterns = [
          /(?:Payment to|Payment for|Purchase at|POS Purchase|Debit Purchase) (.+?)(?:on|for|\d|$)/i,
          /(.+?)(?:\*|(?:\d{2,}))/i,
          /(.+?) (?:subscription|recurring)/i
        ];
        
        for (const pattern of patterns) {
          const match = description.match(pattern);
          if (match && match[1]) {
            return match[1].trim();
          }
        }
        
        // Fallback: Use the first 1-3 words of the description
        const words = description.split(/\s+/);
        return words.slice(0, Math.min(3, words.length)).join(' ');
      };
      
      // Parse CSV content into transactions
      const parsedTransactions = parseCSV(csvContent);
      
      if (parsedTransactions.length === 0) {
        return res.status(400).json({ message: "No valid transactions found in CSV" });
      }
      
      // Validate and insert transactions
      const validTransactions = parsedTransactions.map(transaction => ({
        userId,
        date: new Date(transaction.date),
        description: transaction.description,
        amount: transaction.amount,
        vendor: transaction.vendor,
        data: transaction.data || {}
      }));
      
      const createdTransactions = await storage.createTransactions(validTransactions);
      
      // Detect subscriptions based on the transactions
      const detectedSubscriptions = detectSubscriptions(validTransactions);
      
      // Save detected subscriptions
      const createdSubscriptions = await Promise.all(
        detectedSubscriptions.map(subscription => 
          storage.createSubscription({
            ...subscription,
            userId,
          })
        )
      );
      
      res.status(201).json({
        transactions: createdTransactions,
        subscriptions: createdSubscriptions
      });
    } catch (error) {
      console.error("CSV processing error:", error);
      res.status(500).json({ 
        message: "Failed to process CSV data", 
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Stripe one-time payment
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe API not configured" });
      }
      
      const { amount, userId } = req.body;
      
      if (!amount || !userId) {
        return res.status(400).json({ message: "Amount and user ID are required" });
      }
      
      const user = await storage.getUser(parseInt(userId, 10));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Create a PaymentIntent for one-time payment
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: { userId: userId.toString() },
        description: "Subsy one-time payment"
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Stripe payment intent error:", error);
      res.status(500).json({ 
        message: "Failed to create payment intent", 
        error: error.message 
      });
    }
  });

  // Stripe Premium Upgrade
  app.post("/api/create-checkout-session", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe API not configured" });
      }
      
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const user = await storage.getUser(parseInt(userId, 10));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Create a Stripe checkout session
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        client_reference_id: userId.toString(), // Add user ID as reference
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "Subsy Premium",
                description: "Unlimited subscriptions tracking and advanced features",
              },
              unit_amount: 500, // $5.00
            },
            quantity: 1,
          },
        ],
        mode: "subscription",
        success_url: `${req.headers.origin}/dashboard?success=true`,
        cancel_url: `${req.headers.origin}/premium?canceled=true`,
      });

      res.json({ url: session.url });
    } catch (error: any) {
      console.error("Stripe checkout error:", error);
      res.status(500).json({ 
        message: "Failed to create checkout session", 
        error: error.message 
      });
    }
  });

  // Get or create a Stripe subscription
  app.post("/api/get-or-create-subscription", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe API not configured" });
      }
      
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const user = await storage.getUser(parseInt(userId, 10));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // If user already has a subscription
      if (user.stripeSubscriptionId) {
        try {
          const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
          
          // Return the existing subscription's payment intent client secret
          const latestInvoice = await stripe.invoices.retrieve(subscription.latest_invoice as string);
          const paymentIntent = await stripe.paymentIntents.retrieve(latestInvoice.payment_intent as string);
          
          return res.json({
            subscriptionId: subscription.id,
            clientSecret: paymentIntent.client_secret,
          });
        } catch (err) {
          // If subscription retrieval fails, create a new one
          console.log("Failed to retrieve existing subscription, creating new one");
        }
      }

      // Create a customer if needed
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email || undefined,
          name: user.username,
          metadata: { userId: userId.toString() },
        });
        customerId = customer.id;
        
        // Update user with customer ID
        await storage.updateUserStripeInfo(user.id, { stripeCustomerId: customerId });
      }

      // Create the subscription with a payment intent
      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{
          price_data: {
            currency: "usd",
            product_data: {
              name: "Subsy Premium",
              description: "Unlimited subscriptions tracking and advanced features",
            },
            unit_amount: 500, // $5.00
            recurring: {
              interval: "month",
            },
          },
        }],
        payment_behavior: "default_incomplete",
        payment_settings: { save_default_payment_method: "on_subscription" },
        expand: ["latest_invoice.payment_intent"],
      });

      // Update user with subscription ID 
      await storage.updateUserStripeInfo(user.id, { 
        stripeSubscriptionId: subscription.id 
      });

      // Get the client secret from the subscription's latest invoice payment intent
      const latestInvoice = subscription.latest_invoice as any;
      const paymentIntent = latestInvoice.payment_intent as any;

      res.json({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error("Stripe subscription error:", error);
      res.status(500).json({ 
        message: "Failed to create subscription", 
        error: error.message 
      });
    }
  });

  // Stripe webhook for handling successful payments
  app.post("/api/webhook", express.raw({ type: "application/json" }), async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe API not configured" });
    }
    
    const sig = req.headers["stripe-signature"] as string;
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
    
    if (!endpointSecret) {
      return res.status(500).json({ message: "Webhook secret not configured" });
    }
    
    let event;
    
    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        endpointSecret
      );
    } catch (err: any) {
      console.error("Webhook signature verification error:", err);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    
    // Handle completed checkout sessions
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      
      // Update user to premium
      const userId = session.client_reference_id;
      if (userId) {
        await storage.updateUserPremiumStatus(parseInt(userId, 10), true);
        
        // Update Stripe customer ID if needed
        await storage.updateUserStripeInfo(parseInt(userId, 10), {
          stripeCustomerId: session.customer,
          stripeSubscriptionId: session.subscription
        });
      }
    }
    
    // Handle successful payment intents (one-time payments)
    if (event.type === "payment_intent.succeeded") {
      const paymentIntent = event.data.object;
      const metadata = paymentIntent.metadata;
      
      if (metadata && metadata.userId) {
        // Update user to premium status
        await storage.updateUserPremiumStatus(parseInt(metadata.userId, 10), true);
      }
    }
    
    // Handle subscription status changes
    if (event.type === "customer.subscription.updated") {
      const subscription = event.data.object;
      
      // Find the user with this subscription ID
      const users = await storage.getAllUsers();
      const user = users.find(u => u.stripeSubscriptionId === subscription.id);
      
      if (user) {
        // If subscription is active, make sure user is premium
        if (subscription.status === "active") {
          await storage.updateUserPremiumStatus(user.id, true);
        }
        // If subscription is canceled, revoke premium status
        else if (subscription.status === "canceled") {
          await storage.updateUserPremiumStatus(user.id, false);
        }
      }
    }
    
    res.json({ received: true });
  });

  // Helper function to detect subscriptions from transactions
  function detectSubscriptions(transactions: any[]): any[] {
    const potentialSubscriptions = new Map<string, any[]>();
    
    // Group transactions by vendor
    transactions.forEach(transaction => {
      const vendor = transaction.vendor;
      
      // Get the amount from the transaction, make sure it's a numeric value
      const rawAmount = String(transaction.amount).trim();
      console.log('Processing transaction:', { vendor, rawAmount });
      
      // Clean and parse the amount - we need to handle negative values (expenses)
      let amountNum: number | null = null;
      
      try {
        // Remove non-numeric characters except for decimal and negative sign
        const cleanAmount = rawAmount.replace(/[^\d.-]/g, '');
        
        // Parse to a number
        const parsedAmount = parseFloat(cleanAmount);
        
        // Check if it's a valid number
        if (!isNaN(parsedAmount)) {
          // Use absolute value as subscription costs are displayed positively
          amountNum = Math.abs(parsedAmount);
          console.log(`Valid amount found: ${amountNum} from ${rawAmount}`);
        }
      } catch (e) {
        console.error('Error parsing amount:', rawAmount, e);
      }
      
      // Skip transactions without valid amounts
      if (amountNum === null) {
        console.log('Skipping transaction with invalid amount');
        return;
      }
      
      // Create a key using vendor name
      const key = vendor;
      
      // Create entry if it doesn't exist
      if (!potentialSubscriptions.has(key)) {
        potentialSubscriptions.set(key, []);
      }
      
      // Add transaction to the group with the parsed amount
      const entry = { ...transaction, parsedAmount: amountNum };
      potentialSubscriptions.get(key)?.push(entry);
    });
    
    const subscriptions: any[] = [];
    
    // Identify recurring transactions (subscriptions)
    potentialSubscriptions.forEach((vendorTransactions, vendor) => {
      // Need at least 2 transactions to detect a pattern
      if (vendorTransactions.length >= 2) {
        // Group by similar amounts (within 0.01 difference)
        const amountGroups = new Map<number, any[]>();
        
        vendorTransactions.forEach(tx => {
          // Find if there's a similar amount group
          let foundGroup = false;
          
          for (const [amount, group] of amountGroups.entries()) {
            // Check if current transaction amount is within 0.01 of the group key
            if (Math.abs(tx.parsedAmount - amount) < 0.01) {
              group.push(tx);
              foundGroup = true;
              break;
            }
          }
          
          // If no similar group found, create a new one
          if (!foundGroup) {
            amountGroups.set(tx.parsedAmount, [tx]);
          }
        });
        
        // Check each amount group for subscription patterns
        amountGroups.forEach((txGroup, amount) => {
          // Only consider groups with at least 2 transactions
          if (txGroup.length >= 2) {
            // Sort transactions by date
            txGroup.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
            
            // Check for ~30 day intervals
            let isSubscription = false;
            for (let i = 1; i < txGroup.length; i++) {
              const daysDiff = Math.abs(
                (new Date(txGroup[i].date).getTime() - 
                 new Date(txGroup[i-1].date).getTime()) / (1000 * 60 * 60 * 24)
              );
              
              // Allow flexibility in subscription periods (25-35 days)
              if (daysDiff >= 25 && daysDiff <= 35) {
                isSubscription = true;
                break;
              }
            }
            
            if (isSubscription) {
              // Get the most recent transaction date
              const lastPayment = new Date(
                Math.max(...txGroup.map(t => new Date(t.date).getTime()))
              );
              
              // Estimate next payment date (~30 days after last payment)
              const nextPayment = new Date(lastPayment);
              nextPayment.setDate(nextPayment.getDate() + 30);
              
              // Format amount as currency
              const formattedAmount = formatAmount(amount.toString());
              
              console.log('Adding subscription:', {
                name: formatVendorName(vendor),
                amount: amount,
                formattedAmount: formattedAmount
              });
              
              subscriptions.push({
                name: formatVendorName(vendor), // Format vendor name for display
                amount: formattedAmount,
                frequency: "Monthly",
                lastPayment,
                nextPayment,
                status: "Active",
                isStillUsing: true,
                vendor
              });
            }
          }
        });
      }
    });
    
    return subscriptions;
  }
  
  // Helper function to format amount as currency
  function formatAmount(amount: any): string {
    try {
      console.log('Formatting amount:', amount, 'type:', typeof amount);
      
      // Handle cases where amount is already a number
      let amountToFormat: number;
      if (typeof amount === 'number') {
        amountToFormat = amount;
      } else {
        // Clean the string and remove currency symbols, commas, etc.
        const cleanAmount = String(amount).replace(/[^\d.-]/g, '');
        amountToFormat = parseFloat(cleanAmount);
      }
      
      // Take absolute value - subscription costs are displayed as positive
      amountToFormat = Math.abs(amountToFormat);
      console.log('Parsed amount:', amountToFormat);
      
      if (!isNaN(amountToFormat)) {
        // Format to 2 decimal places with dollar sign
        const formatted = `$${amountToFormat.toFixed(2)}`;
        console.log('Formatted amount:', formatted);
        return formatted;
      }
      
      console.log('Invalid amount, returning $0.00');
      return '$0.00';
    } catch (error) {
      console.error('Error formatting amount:', amount, error);
      return '$0.00';
    }
  }
  
  // Helper function to format vendor name for display
  function formatVendorName(vendor: string): string {
    if (!vendor) return 'Unknown';
    
    return vendor
      .split(' ')
      .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  const httpServer = createServer(app);
  return httpServer;
}
