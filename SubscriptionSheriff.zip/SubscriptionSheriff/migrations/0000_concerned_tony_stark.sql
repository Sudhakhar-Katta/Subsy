CREATE TABLE "subscriptions" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"name" text NOT NULL,
	"amount" text NOT NULL,
	"frequency" text DEFAULT 'Monthly',
	"last_payment" timestamp,
	"next_payment" timestamp,
	"status" text DEFAULT 'Active',
	"is_still_using" boolean DEFAULT true,
	"vendor" text NOT NULL,
	"logo" text
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"date" timestamp NOT NULL,
	"description" text NOT NULL,
	"amount" text NOT NULL,
	"vendor" text NOT NULL,
	"data" jsonb
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	"email" text,
	"is_premium" boolean DEFAULT false,
	"stripe_customer_id" text,
	"stripe_subscription_id" text,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
