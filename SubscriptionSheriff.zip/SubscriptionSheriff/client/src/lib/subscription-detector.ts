import { parseCSV, type ParsedTransaction } from './csv-parser';

interface Subscription {
  name: string;
  amount: string;
  frequency: string;
  lastPayment: Date;
  nextPayment: Date;
  status: 'Active' | 'Cancelled' | 'Unknown';
  isStillUsing: boolean;
  vendor: string;
  logo?: string;
}

/**
 * Detect recurring subscriptions from bank transactions
 * 
 * @param transactions List of parsed transactions
 * @returns List of detected subscriptions
 */
export function detectSubscriptions(transactions: ParsedTransaction[]): Subscription[] {
  // Group transactions by vendor and amount
  const transactionGroups = new Map<string, ParsedTransaction[]>();
  
  transactions.forEach(transaction => {
    // Normalize the amount to handle different formats
    const normalizedAmount = normalizeAmount(transaction.amount);
    const key = `${transaction.vendor}-${normalizedAmount}`;
    
    if (!transactionGroups.has(key)) {
      transactionGroups.set(key, []);
    }
    transactionGroups.get(key)!.push(transaction);
  });
  
  const subscriptions: Subscription[] = [];
  
  // Analyze each group to detect recurring patterns
  transactionGroups.forEach((group, key) => {
    // We need at least 2 transactions to detect a pattern
    if (group.length >= 2) {
      const [vendor, amount] = key.split('-');
      
      // Sort by date
      group.sort((a, b) => 
        new Date(a.date).getTime() - new Date(b.date).getTime()
      );
      
      // Check for monthly pattern (around 30 days)
      let isRecurring = false;
      const dateDiffs: number[] = [];
      
      for (let i = 1; i < group.length; i++) {
        const prevDate = new Date(group[i-1].date);
        const currDate = new Date(group[i].date);
        const diffDays = Math.round((currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
        
        dateDiffs.push(diffDays);
        
        // Look for approximately monthly payments (25-35 days)
        if (diffDays >= 25 && diffDays <= 35) {
          isRecurring = true;
        }
      }
      
      // Check if this looks like a subscription
      if (isRecurring || 
         (group.length >= 2 && 
          getAverageOf(dateDiffs) >= 25 && 
          getAverageOf(dateDiffs) <= 35)) {
        
        // Get the last transaction date
        const lastTransaction = group[group.length - 1];
        const lastPaymentDate = new Date(lastTransaction.date);
        
        // Estimate next payment date (using average interval if we have it)
        const avgInterval = dateDiffs.length > 0 
          ? getAverageOf(dateDiffs) 
          : 30; // Default to 30 days
        
        const nextPaymentDate = new Date(lastPaymentDate);
        nextPaymentDate.setDate(nextPaymentDate.getDate() + avgInterval);
        
        // Create the subscription object
        subscriptions.push({
          name: formatVendorName(vendor),
          amount: formatAmount(amount),
          frequency: 'Monthly',
          lastPayment: lastPaymentDate,
          nextPayment: nextPaymentDate,
          status: 'Active',
          isStillUsing: true,
          vendor,
          logo: getVendorLogo(vendor)
        });
      }
    }
  });
  
  return subscriptions;
}

/**
 * Normalize transaction amount to handle different formats
 */
function normalizeAmount(amount: string): string {
  // Remove currency symbols, commas, etc. but keep the negative sign if present
  let normalized = amount.replace(/[^\d.-]/g, '');
  
  // Ensure it's a valid number format
  if (normalized && !isNaN(parseFloat(normalized))) {
    return normalized;
  }
  return '0';
}

/**
 * Format amount for display
 */
function formatAmount(amount: string): string {
  try {
    const numAmount = parseFloat(amount);
    // Use absolute value since subscription costs are typically positive in display
    // Even though in bank statements they appear as negative values (money going out)
    return `$${Math.abs(numAmount).toFixed(2)}`;
  } catch (error) {
    console.warn('Error formatting amount:', amount, error);
    return '$0.00';
  }
}

/**
 * Calculate average of an array of numbers
 */
function getAverageOf(numbers: number[]): number {
  if (numbers.length === 0) return 0;
  return numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
}

/**
 * Format vendor name for display
 */
function formatVendorName(vendor: string): string {
  return vendor
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Get vendor logo based on vendor name
 * For real implementation, you would use a proper logo lookup service
 */
function getVendorLogo(vendor: string): string | undefined {
  const normalizedVendor = vendor.toLowerCase();
  
  // Map of common vendor names to their first letter
  // In a real app, you would use actual logos or a logo API
  if (normalizedVendor.includes('netflix')) return 'N';
  if (normalizedVendor.includes('spotify')) return 'S';
  if (normalizedVendor.includes('adobe')) return 'A';
  if (normalizedVendor.includes('apple')) return 'A';
  if (normalizedVendor.includes('amazon')) return 'A';
  if (normalizedVendor.includes('disney')) return 'D';
  if (normalizedVendor.includes('hulu')) return 'H';
  if (normalizedVendor.includes('dropbox')) return 'D';
  if (normalizedVendor.includes('google')) return 'G';
  if (normalizedVendor.includes('microsoft')) return 'M';
  
  // For other vendors, return undefined (will use first letter in UI)
  return undefined;
}

/**
 * Process a CSV file to detect subscriptions
 */
export async function processCSVFile(file: File): Promise<{
  transactions: ParsedTransaction[];
  subscriptions: Subscription[];
}> {
  try {
    const csvContent = await readCSVFile(file);
    const transactions = parseCSV(csvContent);
    const subscriptions = detectSubscriptions(transactions);
    
    return { transactions, subscriptions };
  } catch (error) {
    console.error('Error processing CSV file:', error);
    throw error;
  }
}

/**
 * Read a CSV file using the File API
 */
function readCSVFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      if (event.target && typeof event.target.result === 'string') {
        resolve(event.target.result);
      } else {
        reject(new Error('Failed to read CSV file'));
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Error reading CSV file'));
    };
    
    reader.readAsText(file);
  });
}
