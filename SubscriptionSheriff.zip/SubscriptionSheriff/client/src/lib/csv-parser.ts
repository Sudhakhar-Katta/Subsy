/**
 * CSV Parser for bank statements
 */

export interface ParsedTransaction {
  date: string;
  description: string;
  amount: string;
  vendor: string;
  data?: Record<string, any>;
}

/**
 * Parse CSV data from a bank statement
 * 
 * @param csvString The CSV string to parse
 */
export function parseCSV(csvString: string): ParsedTransaction[] {
  // Split the CSV into lines
  const lines = csvString.split(/\r?\n/).filter(line => line.trim() !== '');
  
  if (lines.length < 2) {
    throw new Error('CSV file must contain a header row and at least one data row');
  }
  
  // Extract the header row
  const headers = lines[0].split(',').map(header => header.trim().toLowerCase());
  
  // Find essential column indexes
  const dateIndex = headers.findIndex(header => 
    header.includes('date') || header.includes('time')
  );
  
  const descriptionIndex = headers.findIndex(header => 
    header.includes('description') || header.includes('desc') || 
    header.includes('transaction') || header.includes('detail')
  );
  
  const amountIndex = headers.findIndex(header => 
    header.includes('amount') || header.includes('sum') || 
    header.includes('payment') || header.includes('debit')
  );
  
  // Ensure all required columns are present
  if (dateIndex === -1 || descriptionIndex === -1 || amountIndex === -1) {
    throw new Error('CSV file must contain date, description, and amount columns');
  }
  
  // Parse data rows
  const transactions: ParsedTransaction[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    // Handle quoted fields that may contain commas
    const parsedLine = parseCSVLine(lines[i]);
    
    if (parsedLine.length <= Math.max(dateIndex, descriptionIndex, amountIndex)) {
      continue; // Skip rows that don't have enough fields
    }
    
    const date = parsedLine[dateIndex].trim();
    const description = parsedLine[descriptionIndex].trim();
    
    // Process amount: first clean it then ensure it's a valid number
    let rawAmount = parsedLine[amountIndex].trim();
    console.log(`CSV parser processing amount: ${rawAmount}`);
    
    // Check if this is a debit (negative amount) by looking for indicators
    const isDebit = rawAmount.includes('-') || 
                    rawAmount.toLowerCase().includes('debit') ||
                    (headers[amountIndex].toLowerCase().includes('debit'));
    
    // Clean the amount string and convert to number
    let amount = rawAmount.replace(/[^\d.-]/g, ''); // Remove non-numeric chars except for - and .
    
    // If amount is positive but should be a debit (outgoing payment), make it negative
    // This is important for subscription detection
    if (!amount.includes('-') && isDebit) {
      amount = '-' + amount;
    }
    
    // Extract vendor name from description
    const vendor = extractVendorName(description);
    
    console.log(`CSV parser detected: ${vendor}, amount: ${amount}`);
    
    // Create an object with all columns as data
    const data: Record<string, string> = {};
    headers.forEach((header, index) => {
      if (index < parsedLine.length) {
        data[header] = parsedLine[index].trim();
      }
    });
    
    transactions.push({
      date,
      description,
      amount,
      vendor,
      data
    });
  }
  
  return transactions;
}

/**
 * Parse a CSV line, handling quoted fields correctly
 */
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      // Toggle quote mode
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      // End of field
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  // Don't forget the last field
  result.push(current);
  
  return result;
}

/**
 * Extract vendor name from transaction description
 */
function extractVendorName(description: string): string {
  // Common patterns in transaction descriptions
  const patterns = [
    /(?:Payment to|Payment for|Purchase at|POS Purchase|Debit Purchase) (.+?)(?:on|for|\d|$)/i,
    /(.+?)(?:\*|(?:\d{2,}))/i,
    /(.+?) (?:subscription|recurring)/i
  ];
  
  for (const pattern of patterns) {
    const match = description.match(pattern);
    if (match && match[1]) {
      return match[1].trim();
    }
  }
  
  // Fallback: Use the first 1-3 words of the description
  const words = description.split(/\s+/);
  return words.slice(0, Math.min(3, words.length)).join(' ');
}

/**
 * Read a CSV file using the File API
 */
export function readCSVFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      if (event.target && typeof event.target.result === 'string') {
        resolve(event.target.result);
      } else {
        reject(new Error('Failed to read CSV file'));
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Error reading CSV file'));
    };
    
    reader.readAsText(file);
  });
}
