import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PremiumUpgradeProps {
  userId?: number;
}

const PremiumUpgrade = ({ userId = 1 }: PremiumUpgradeProps) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  
  // Check if URL has canceled query param for Stripe
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const canceled = urlParams.get("canceled") === "true";
    
    if (canceled) {
      toast({
        title: "Payment canceled",
        description: "Your payment was canceled. You can try again anytime.",
        variant: "destructive",
      });
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast]);
  
  const handleUpgradeClick = async () => {
    setIsLoading(true);
    
    try {
      // Redirect to subscribe page with userId
      setLocation(`/subscribe?userId=${userId}`);
    } catch (error) {
      setIsLoading(false);
      toast({
        title: "Error starting subscription process",
        description: error instanceof Error ? error.message : "Failed to process payment request",
        variant: "destructive",
      });
    }
  };
  
  return (
    <section className="min-h-screen bg-gray-50 flex items-center justify-center p-6 md:p-10">
      <div className="max-w-lg w-full bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 pb-0">
          <Link to="/dashboard">
            <Button variant="ghost" className="text-gray-500 hover:text-gray-700 text-sm font-medium">
              &larr; Back to Dashboard
            </Button>
          </Link>
        </div>
        
        <div className="p-6">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary mb-4">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-8 h-8 text-charcoal">
                <path d="M20.2 7.8l-7.7 7.7-4-4-5.7 5.7"/>
                <path d="M15 7h6v6"/>
              </svg>
            </div>
            <h2 className="text-2xl font-semibold">Unlock Premium Features</h2>
            <p className="text-gray-600 mt-1">Manage all your subscriptions effortlessly</p>
          </div>
          
          <div className="bg-gradient-to-r from-secondary/20 to-primary/20 rounded-xl p-6 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-lg">Subsy Premium</h3>
              <div className="bg-white rounded-full px-3 py-1 text-sm font-medium shadow-sm">
                $5/month
              </div>
            </div>
            
            <ul className="space-y-3">
              <li className="flex items-start">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600 mt-0.5 mr-2">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span>Track unlimited subscriptions</span>
              </li>
              <li className="flex items-start">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600 mt-0.5 mr-2">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span>Auto-cancel future charges</span>
              </li>
              <li className="flex items-start">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600 mt-0.5 mr-2">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span>Advanced insights & recommendations</span>
              </li>
              <li className="flex items-start">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600 mt-0.5 mr-2">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span>Upcoming charges notifications</span>
              </li>
              <li className="flex items-start">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600 mt-0.5 mr-2">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span>Direct bank integration (Plaid)</span>
              </li>
            </ul>
          </div>
          
          <Button 
            className="w-full bg-primary hover:bg-primary-dark text-charcoal font-medium rounded-lg px-6 py-4 transition duration-200 flex items-center justify-center gap-2 mb-4"
            onClick={handleUpgradeClick}
            disabled={isLoading}
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-charcoal border-t-transparent rounded-full animate-spin mr-2" />
            ) : (
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5 mr-1">
                <rect x="3" y="5" width="18" height="14" rx="2"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
            )}
            {isLoading ? "Processing..." : "Upgrade with Stripe"}
          </Button>
          
          <p className="text-center text-sm text-gray-500">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-4 h-4 text-green-600 inline mr-1">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            Try risk-free. Cancel anytime, no questions asked.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PremiumUpgrade;
