import { Button } from "@/components/ui/button";
import { formatDistanceToNow, format } from "date-fns";

interface Subscription {
  id: number;
  name: string;
  amount: string;
  frequency: string;
  lastPayment: string;
  nextPayment: string;
  status: 'Active' | 'Cancelled' | 'Unknown';
  isStillUsing: boolean;
  vendor: string;
  logo?: string;
}

interface SubscriptionItemProps {
  subscription: Subscription;
  onUsageChange: (id: number, isStillUsing: boolean) => void;
  onCancelClick: () => void;
}

const SubscriptionItem = ({ subscription, onUsageChange, onCancelClick }: SubscriptionItemProps) => {
  const {
    id,
    name,
    amount,
    lastPayment,
    nextPayment,
    isStillUsing,
  } = subscription;
  
  // Get first letter of name for logo fallback
  const firstLetter = name.charAt(0).toUpperCase();
  
  // Get background color based on name
  const getBackgroundColor = (name: string) => {
    const colors = [
      'bg-red-100', 'bg-blue-100', 'bg-green-100', 'bg-yellow-100',
      'bg-purple-100', 'bg-pink-100', 'bg-indigo-100', 'bg-gray-100'
    ];
    
    // Use a hash function to get a consistent color for a name
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    const index = Math.abs(hash) % colors.length;
    return colors[index];
  };
  
  // Get text color based on background
  const getTextColor = (bgColor: string) => {
    const colorMap = {
      'bg-red-100': 'text-red-600',
      'bg-blue-100': 'text-blue-600',
      'bg-green-100': 'text-green-600',
      'bg-yellow-100': 'text-yellow-600',
      'bg-purple-100': 'text-purple-600',
      'bg-pink-100': 'text-pink-600',
      'bg-indigo-100': 'text-indigo-600',
      'bg-gray-100': 'text-gray-600'
    };
    
    return colorMap[bgColor] || 'text-gray-600';
  };
  
  const bgColor = getBackgroundColor(name);
  const textColor = getTextColor(bgColor);
  
  // Format dates
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return format(date, 'MMMM d, yyyy');
    } catch {
      return 'Unknown date';
    }
  };
  
  // Format next payment
  const formatNextPayment = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return format(date, 'MMM d, yyyy');
    } catch {
      return 'Unknown';
    }
  };
  
  return (
    <div className={`bg-white ${!isStillUsing ? 'border-2 border-red-200' : ''} rounded-xl shadow-sm p-5 hover:shadow-md transition-shadow`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-lg ${bgColor} flex items-center justify-center flex-shrink-0`}>
            <span className={`${textColor} font-bold`}>{firstLetter}</span>
          </div>
          <div>
            <h3 className="font-medium">{name}</h3>
            <p className="text-sm text-gray-500">Last charge: {formatDate(lastPayment)}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-medium">{amount}/mo</p>
          <p className="text-sm text-gray-500">Next: {formatNextPayment(nextPayment)}</p>
        </div>
      </div>
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
        <div className="flex items-center">
          <span className="text-sm mr-2">Still using?</span>
          <div className="flex items-center">
            <button 
              className={`${isStillUsing ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'} px-2 py-1 rounded text-xs font-medium mr-1`}
              onClick={() => onUsageChange(id, true)}
            >
              Yes
            </button>
            <button 
              className={`${!isStillUsing ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'} px-2 py-1 rounded text-xs font-medium`}
              onClick={() => onUsageChange(id, false)}
            >
              No
            </button>
          </div>
        </div>
        <Button 
          variant={!isStillUsing ? "destructive" : "ghost"} 
          className={!isStillUsing ? "bg-red-500 hover:bg-red-600 text-white px-3 py-1 text-sm" : "text-red-500 hover:text-red-700 text-sm font-medium"}
          onClick={onCancelClick}
        >
          {!isStillUsing ? "Cancel Now" : "Cancel"}
        </Button>
      </div>
    </div>
  );
};

export default SubscriptionItem;
