const ProcessingScreen = () => {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center p-6 md:p-10 bg-white">
      <div className="max-w-md w-full text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 mb-6">
          <div className="w-16 h-16 border-4 border-primary border-t-secondary rounded-full animate-spin"></div>
        </div>
        <h2 className="text-2xl font-semibold">Analyzing Your Transactions</h2>
        <p className="text-gray-600 mt-2">This may take a moment as we find your recurring subscriptions...</p>
      </div>
    </section>
  );
};

export default ProcessingScreen;
