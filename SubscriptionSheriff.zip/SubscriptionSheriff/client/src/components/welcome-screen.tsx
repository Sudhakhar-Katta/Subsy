import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const WelcomeScreen = () => {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center p-6 md:p-10 relative">
      <div className="absolute inset-0 overflow-hidden">
        <svg className="h-full w-full opacity-10" viewBox="0 0 1000 1000" preserveAspectRatio="xMidYMid slice">
          <defs>
            <pattern id="pattern" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
              <circle cx="5" cy="5" r="1.6" fill="#b8f2e6" />
            </pattern>
          </defs>
          <rect x="0" y="0" width="100%" height="100%" fill="url(#pattern)" />
        </svg>
      </div>
      
      <div className="z-10 flex flex-col items-center justify-center max-w-md w-full text-center space-y-8">
        <div className="w-32 h-32 rounded-full bg-primary flex items-center justify-center shadow-lg">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="w-16 h-16 text-charcoal">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
        </div>
        
        <div className="space-y-4">
          <h1 className="text-4xl font-semibold tracking-tight">Welcome to Subsy</h1>
          <p className="text-lg text-gray-600">Find and cancel hidden subscriptions in seconds.</p>
        </div>
        
        <Link href="/connect">
          <Button className="w-full bg-primary hover:bg-primary-dark text-charcoal font-medium rounded-lg px-6 py-7 transition duration-200 shadow-md text-lg">
            Get Started
          </Button>
        </Link>
        
        <p className="text-sm text-gray-500">
          Already have an account? <Link href="/login" className="text-blue-500 hover:underline">Sign in</Link>
        </p>
      </div>
    </section>
  );
};

export default WelcomeScreen;
