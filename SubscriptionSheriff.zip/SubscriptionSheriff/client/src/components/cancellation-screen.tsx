import { Button } from "@/components/ui/button";
import { Link, useParams } from "wouter";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";

interface CancellationScreenProps {
  userId?: number;
}

const CancellationScreen = ({ userId = 1 }: CancellationScreenProps) => {
  const [emailSent, setEmailSent] = useState(false);
  const { id } = useParams<{ id: string }>();
  
  const { data: subscriptionData, isLoading } = useQuery({
    queryKey: [`/api/subscriptions/${id}`],
  });
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary border-t-secondary rounded-full animate-spin"></div>
      </div>
    );
  }
  
  // Make sure we have a valid subscription with default values for all fields
  const subscription = subscriptionData && subscriptionData.length > 0 ? subscriptionData[0] : {
    id: parseInt(id || '0'),
    userId: userId,
    name: "Subscription",
    amount: "$0.00",
    frequency: "Monthly",
    lastPayment: new Date().toISOString(),
    nextPayment: new Date().toISOString(),
    status: "Active",
    isStillUsing: true,
    vendor: "Unknown",
    logo: ""
  };
  
  // Format dates
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return format(date, 'MMMM d, yyyy');
    } catch {
      return 'Unknown date';
    }
  };
  
  // Generate customized email content based on subscription type
  const getCustomizedContent = () => {
    // Common subscriptions templates
    const templates: Record<string, {subject: string, body: string, email: string}> = {
      // Music streaming services
      "spotify": {
        subject: `Request to Cancel Spotify Premium Subscription`,
        body: `Hello Spotify Support Team,

I would like to cancel my Spotify Premium subscription associated with this email address. Please process this cancellation request immediately to avoid further charges.

Account Information:
Email: [YOUR EMAIL]
Username: [YOUR USERNAME]
Subscription Plan: Premium ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Last Payment Date: ${formatDate(subscription.lastPayment)}

If you require any additional information to process this cancellation, please let me know.

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "support@spotify.com"
      },
      
      "apple music": {
        subject: `Request to Cancel Apple Music Subscription`,
        body: `Hello Apple Support Team,

I would like to cancel my Apple Music subscription associated with this Apple ID. Please process this cancellation request.

Account Information:
Apple ID: [YOUR APPLE ID]
Subscription: Apple Music ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Last Payment: ${formatDate(subscription.lastPayment)}

Note: I understand I can also cancel this subscription through my Apple ID settings.

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "support@apple.com"
      },
      
      "youtube": {
        subject: `Request to Cancel YouTube Premium Subscription`,
        body: `Hello YouTube Support Team,

I would like to cancel my YouTube Premium subscription associated with this Google account. Please process this cancellation request immediately.

Account Information:
Google Account: [YOUR EMAIL]
Subscription: YouTube Premium ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Last Payment Date: ${formatDate(subscription.lastPayment)}

I understand I can also manage my subscription through my Google account settings, but I'm requesting direct assistance for this cancellation.

Thank you for your help.

Sincerely,
[YOUR NAME]`,
        email: "support@youtube.com"
      },
      
      // Video streaming
      "netflix": {
        subject: `Request to Cancel Netflix Subscription`,
        body: `Hello Netflix Customer Service,

I would like to cancel my Netflix subscription effective immediately. Please process this cancellation request and confirm once completed.

Account Information:
Email: [YOUR EMAIL]
Subscription Plan: ${subscription.amount ? `${subscription.amount}/month` : 'Standard'}
Billing Date: ${formatDate(subscription.nextPayment)}

Thank you for your prompt attention to this matter.

Sincerely,
[YOUR NAME]`,
        email: "cancel@netflix.com"
      },
      
      "hulu": {
        subject: `Request to Cancel Hulu Subscription`,
        body: `Hello Hulu Support Team,

I'm writing to request cancellation of my Hulu subscription effective immediately. Please process this cancellation and confirm once completed.

Account Information:
Email: [YOUR EMAIL]
Subscription Plan: ${subscription.amount ? `${subscription.amount}/month` : 'Standard'}
Billing Date: ${formatDate(subscription.nextPayment)}

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "support@hulu.com"
      },
      
      "disney": {
        subject: `Request to Cancel Disney+ Subscription`,
        body: `Hello Disney+ Support Team,

I would like to cancel my Disney+ subscription. Please process this cancellation request as soon as possible.

Account Information:
Email: [YOUR EMAIL]
Subscription: Disney+ ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Next Billing Date: ${formatDate(subscription.nextPayment)}

Please confirm once the cancellation has been processed.

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "support@disneyplus.com"
      },
      
      // Software subscriptions
      "adobe": {
        subject: `Request to Cancel Adobe Creative Cloud Subscription`,
        body: `Hello Adobe Support Team,

I'm writing to request cancellation of my Adobe Creative Cloud subscription. Please process this request as soon as possible.

Account Information:
Adobe ID: [YOUR ADOBE ID]
Email: [YOUR EMAIL]
Subscription: Creative Cloud ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Account Number: [YOUR ACCOUNT NUMBER, IF AVAILABLE]

I understand there may be an early termination fee if I'm still within my contract period. Please inform me of any final charges.

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "support@adobe.com"
      },
      
      "microsoft": {
        subject: `Request to Cancel Microsoft 365 Subscription`,
        body: `Hello Microsoft Subscription Support,

I would like to cancel my Microsoft 365 subscription. Please process this cancellation request.

Account Information:
Microsoft Account: [YOUR EMAIL]
Subscription: Microsoft 365 ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Billing Cycle: Monthly

Please confirm once the cancellation has been processed.

Thank you,
[YOUR NAME]`,
        email: "support@microsoft.com"
      },
      
      // Fitness
      "peloton": {
        subject: `Request to Cancel Peloton All-Access Membership`,
        body: `Hello Peloton Support Team,

I would like to cancel my Peloton All-Access Membership effective immediately. Please process this cancellation request.

Account Information:
Email: [YOUR EMAIL]
Username: [YOUR USERNAME]
Membership Type: All-Access ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Last Payment Date: ${formatDate(subscription.lastPayment)}

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "support@onepeloton.com"
      },
      
      "planet fitness": {
        subject: `Request to Cancel Planet Fitness Membership`,
        body: `Hello Planet Fitness Customer Service,

I am writing to request cancellation of my Planet Fitness membership effective immediately. Please process this cancellation request.

Account Information:
Member Name: [YOUR FULL NAME]
Member Number: [YOUR MEMBER NUMBER IF AVAILABLE]
Location: [YOUR HOME GYM LOCATION]
Email: [YOUR EMAIL]
Membership Type: ${subscription.amount ? `(${subscription.amount}/month)` : 'Standard'}

I understand that I may need to visit in person to complete this process, but I would like to initiate the cancellation through this email. Please advise me of any additional steps needed.

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "customerservice@planetfitness.com"
      },
      
      // News & Media
      "new york times": {
        subject: `Request to Cancel New York Times Digital Subscription`,
        body: `Hello New York Times Customer Care,

I would like to cancel my digital subscription to The New York Times. Please process this cancellation request immediately.

Account Information:
Email: [YOUR EMAIL]
Subscription Type: Digital ${subscription.amount ? `(${subscription.amount}/month)` : ''}
Last Billing Date: ${formatDate(subscription.lastPayment)}

I would appreciate confirmation when the cancellation has been processed.

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
        email: "help@nytimes.com"
      },
      
      // Delivery Services
      "hello fresh": {
        subject: `Request to Cancel HelloFresh Subscription`,
        body: `Hello HelloFresh Customer Service,

I'm writing to request cancellation of my HelloFresh meal delivery subscription. Please process this cancellation effective immediately to prevent any further deliveries or charges.

Account Information:
Email: [YOUR EMAIL]
Subscription Plan: ${subscription.amount ? `(${subscription.amount} per delivery)` : 'Weekly box'}
Next Scheduled Delivery: ${formatDate(subscription.nextPayment)}

Thank you for your prompt attention to this matter.

Sincerely,
[YOUR NAME]`,
        email: "help@hellofresh.com"
      }
    };
    
    // Find a matching template based on subscription name
    const subscriptionLower = subscription.name.toLowerCase();
    const matchedTemplate = Object.keys(templates).find(key => subscriptionLower.includes(key));
    
    if (matchedTemplate) {
      return templates[matchedTemplate];
    }
    
    // Default generic template
    return {
      subject: `Request to Cancel ${subscription.name} Subscription`,
      body: `Hello ${subscription.name} Support Team,

I would like to cancel my ${subscription.name} subscription associated with this email address. Please process this cancellation request as soon as possible.

Account Information:
Email: [YOUR EMAIL]
Subscription: ${subscription.name}
${subscription.amount ? `Amount: ${subscription.amount}/month` : ''}
${subscription.lastPayment ? `Last Payment Date: ${formatDate(subscription.lastPayment)}` : ''}
${subscription.nextPayment ? `Next Billing Date: ${formatDate(subscription.nextPayment)}` : ''}

Thank you for your assistance.

Sincerely,
[YOUR NAME]`,
      email: `support@${subscription.vendor.toLowerCase().replace(/\s+/g, '')}.com`
    };
  };
  
  // Get customized content
  const emailContent = getCustomizedContent();
  const emailSubject = emailContent.subject;
  const emailBody = emailContent.body;
  const supportEmail = emailContent.email;
  
  // Create mailto link with the proper support email address
  const mailtoLink = `mailto:${supportEmail}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
  
  // Handle send email click
  const handleSendEmail = () => {
    window.location.href = mailtoLink;
    setEmailSent(true);
  };
  
  // Get first letter of name for logo
  const firstLetter = subscription.name.charAt(0).toUpperCase();
  
  return (
    <section className="min-h-screen bg-gray-50 flex items-center justify-center p-6 md:p-10">
      <div className="max-w-lg w-full bg-white rounded-xl shadow-md overflow-hidden">
        <div className="bg-red-50 px-6 py-4">
          <Link href="/dashboard">
            <Button variant="ghost" className="text-gray-500 hover:text-gray-700 text-sm font-medium">
              &larr; Back to Dashboard
            </Button>
          </Link>
        </div>
        
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
              <span className="text-gray-600 font-bold">{firstLetter}</span>
            </div>
            <div>
              <h2 className="text-xl font-semibold">Cancel {subscription.name}?</h2>
              <p className="text-gray-500">{subscription.amount}/month · Renews on {formatDate(subscription.nextPayment)}</p>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h3 className="font-medium mb-2">Ready to send cancellation email:</h3>
            <div className="bg-white rounded border border-gray-200 p-3">
              <p className="text-gray-500 text-sm mb-1"><strong>To:</strong> {supportEmail}</p>
              <p className="text-gray-500 text-sm mb-1"><strong>Subject:</strong> {emailSubject}</p>
              <div className="border-t border-gray-100 pt-2 mt-2">
                <div className="text-gray-700 text-sm whitespace-pre-line">
                  {emailBody}
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col gap-3">
            <Button 
              onClick={handleSendEmail} 
              className="bg-red-500 hover:bg-red-600 text-white py-3 rounded-lg font-medium transition-colors"
              disabled={emailSent}
            >
              {emailSent ? "Email Sent" : "Send Email"}
            </Button>
            
            <Button 
              variant="outline" 
              className="bg-white border border-gray-300 hover:bg-gray-50 text-charcoal py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
              disabled={true}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="12" y1="18" x2="12" y2="12"/>
                <line x1="9" y1="15" x2="15" y2="15"/>
              </svg>
              Download as PDF (Coming Soon)
            </Button>
            
            <Link href="/premium" className="block">
              <p className="text-sm text-primary hover:text-primary/90 text-center mt-3 cursor-pointer">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-4 h-4 text-primary inline mr-1">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="16" x2="12" y2="12"/>
                  <line x1="12" y1="8" x2="12.01" y2="8"/>
                </svg>
                Upgrade to Premium for one-click cancellations
              </p>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CancellationScreen;
