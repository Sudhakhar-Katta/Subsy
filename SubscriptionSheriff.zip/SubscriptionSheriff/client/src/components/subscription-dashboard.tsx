import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { LogOut, User } from "lucide-react";
import SubscriptionItem from "./subscription-item";
import ConnectAccount from "./connect-account";

interface Subscription {
  id: number;
  name: string;
  amount: string;
  frequency: string;
  lastPayment: string;
  nextPayment: string;
  status: 'Active' | 'Cancelled' | 'Unknown';
  isStillUsing: boolean;
  vendor: string;
  logo?: string;
}

interface User {
  id: number;
  username: string;
  email?: string;
  isPremium: boolean;
}

interface SubscriptionDashboardProps {
  userId?: number;
  user?: User;
}

const SubscriptionDashboard = ({ userId = 1, user }: SubscriptionDashboardProps) => {
  const [sortOption, setSortOption] = useState("price");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { logout } = useAuth();
  const [showUploadForm, setShowUploadForm] = useState(false);
  
  const handleLogout = async () => {
    try {
      await logout();
      setLocation('/login');
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "An error occurred during logout",
        variant: "destructive",
      });
    }
  };
  
  const { data: subscriptions, isLoading, isError } = useQuery<Subscription[]>({
    queryKey: [`/api/subscriptions/${userId}`],
  });

  // Calculate total monthly cost
  const totalMonthly = subscriptions?.reduce((total, sub) => {
    const amount = parseFloat(sub.amount.replace(/[^0-9.-]+/g, ""));
    return total + amount;
  }, 0) || 0;

  // Calculate potential savings (unused subscriptions)
  const potentialSavings = subscriptions?.reduce((total, sub) => {
    if (!sub.isStillUsing) {
      const amount = parseFloat(sub.amount.replace(/[^0-9.-]+/g, ""));
      return total + amount;
    }
    return total;
  }, 0) || 0;

  // Sort subscriptions based on the selected option
  const sortedSubscriptions = [...(subscriptions || [])].sort((a, b) => {
    if (sortOption === "price") {
      return parseFloat(b.amount.replace(/[^0-9.-]+/g, "")) - parseFloat(a.amount.replace(/[^0-9.-]+/g, ""));
    } else if (sortOption === "name") {
      return a.name.localeCompare(b.name);
    } else {
      // Sort by date
      return new Date(b.lastPayment).getTime() - new Date(a.lastPayment).getTime();
    }
  });

  const updateSubscriptionMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Subscription> }) => {
      const response = await apiRequest('PATCH', `/api/subscriptions/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/subscriptions/${userId}`] });
      toast({
        title: "Subscription updated",
        description: "Your subscription has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update subscription",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    }
  });

  // Check if URL has success query param for Stripe
  useEffect(() => {
    const url = new URL(window.location.href);
    const success = url.searchParams.get("success");
    
    if (success === "true") {
      toast({
        title: "Premium Upgrade Successful!",
        description: "You now have access to premium features",
      });
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast]);

  // Handle user still using toggle
  const handleUsageChange = (id: number, isStillUsing: boolean) => {
    updateSubscriptionMutation.mutate({
      id,
      updates: { isStillUsing }
    });
  };

  // Handle subscription cancel click
  const handleCancelClick = (subscription: Subscription) => {
    setLocation(`/cancel/${subscription.id}`);
  };

  if (showUploadForm) {
    return (
      <ConnectAccount 
        userId={userId} 
        onSuccess={() => setShowUploadForm(false)} 
      />
    );
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="w-16 h-16 border-4 border-primary border-t-secondary rounded-full animate-spin"></div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center py-10">
        <h2 className="text-2xl text-red-500">Error loading subscriptions</h2>
        <p className="mt-2">Please try again later</p>
        <Button onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/subscriptions/${userId}`] })} className="mt-4">
          Retry
        </Button>
      </div>
    );
  }

  // If no subscriptions, show upload form
  if (!subscriptions || subscriptions.length === 0) {
    return (
      <div className="max-w-md mx-auto text-center py-20 px-4">
        <div className="w-20 h-20 bg-primary/20 rounded-full mx-auto flex items-center justify-center mb-6">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="w-10 h-10 text-primary-dark">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
            <line x1="9" y1="9" x2="15" y2="9"/>
            <line x1="9" y1="15" x2="15" y2="15"/>
          </svg>
        </div>
        <h2 className="text-2xl font-semibold mb-2">No subscriptions found</h2>
        <p className="text-gray-600 mb-6">Upload your bank statement to find your recurring subscriptions</p>
        <Button 
          onClick={() => setShowUploadForm(true)}
          className="bg-primary hover:bg-primary-dark text-charcoal"
        >
          Upload Bank Statement
        </Button>
      </div>
    );
  }

  return (
    <section className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold pl-2">Subsy</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-gray-500 hover:text-gray-700" onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/subscriptions/${userId}`] })}>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5">
                <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38"/>
              </svg>
            </Button>
            
            {/* Logout Button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-gray-500 hover:text-gray-700" 
              onClick={handleLogout}
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </Button>
            
            <div className="relative">
              <Button variant="ghost" className="flex items-center gap-2 text-gray-600 hover:text-gray-800">
                <div className="flex items-center">
                  <span>{user?.username || "User"}</span>
                  {user?.isPremium && (
                    <div className="ml-2 px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium flex items-center">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="w-3 h-3 mr-1">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                      </svg>
                      Premium
                    </div>
                  )}
                </div>
                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="w-5 h-5" />
                </div>
              </Button>
            </div>
          </div>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Total Spending Card */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Spending This Month</p>
                <h2 className="text-3xl font-semibold mt-1">${totalMonthly.toFixed(2)}</h2>
              </div>
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="16"/>
                  <line x1="8" y1="12" x2="16" y2="12"/>
                </svg>
              </div>
            </div>
          </div>
          
          {/* Potential Savings Card */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm">Potential Savings</p>
                <h2 className="text-3xl font-semibold mt-1 text-green-600">${potentialSavings.toFixed(2)}</h2>
              </div>
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-green-600">
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M16 8l-8 8"/>
                  <path d="M8 8l8 8"/>
                </svg>
              </div>
            </div>
          </div>
          
          {/* Subscriptions Count Card */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm">Active Subscriptions</p>
                <h2 className="text-3xl font-semibold mt-1">{subscriptions.length}</h2>
              </div>
              <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-5 h-5 text-blue-600">
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                  <line x1="16" y1="2" x2="16" y2="6"/>
                  <line x1="8" y1="2" x2="8" y2="6"/>
                  <line x1="3" y1="10" x2="21" y2="10"/>
                </svg>
              </div>
            </div>
          </div>
        </div>
        
        {/* Subscription List */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold">Your Subscriptions</h2>
            <div className="flex items-center gap-2">
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="bg-white border border-gray-300 rounded-lg py-2 px-3 text-sm w-40">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price">Sort by: Price</SelectItem>
                  <SelectItem value="name">Sort by: Name</SelectItem>
                  <SelectItem value="date">Sort by: Date</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                className="bg-primary hover:bg-primary-dark text-charcoal text-sm"
                onClick={() => setShowUploadForm(true)}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-4 h-4 mr-1">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                  <polyline points="17 8 12 3 7 8"/>
                  <line x1="12" y1="3" x2="12" y2="15"/>
                </svg> 
                Update Data
              </Button>
            </div>
          </div>
          
          {/* Premium Upsell Notice (For Free Users) */}
          {!user?.isPremium && (
            <div className="bg-gradient-to-r from-secondary/30 to-primary/30 rounded-xl p-5 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="w-6 h-6 text-yellow-600">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Unlock Premium Features</h3>
                    <p className="text-sm text-gray-700 mt-1">Get unlimited subscription tracking, advanced insights, and auto-cancellation assistance for just $5/month.</p>
                    <ul className="text-sm text-gray-700 mt-2 space-y-1">
                      <li className="flex items-center">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          className="w-4 h-4 mr-2 text-green-600">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                        Unlimited subscription tracking
                      </li>
                      <li className="flex items-center">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          className="w-4 h-4 mr-2 text-green-600">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                        Automatic cancellation assistance
                      </li>
                    </ul>
                  </div>
                </div>
                <Link to="/premium">
                  <Button className="bg-white text-charcoal hover:bg-gray-100 shadow-sm">
                    Upgrade to Premium
                  </Button>
                </Link>
              </div>
            </div>
          )}
          
          {/* Subscription Cards */}
          <div className="space-y-4">
            {sortedSubscriptions.map((subscription) => (
              <SubscriptionItem
                key={subscription.id}
                subscription={subscription}
                onUsageChange={handleUsageChange}
                onCancelClick={() => handleCancelClick(subscription)}
              />
            ))}
          </div>
        </div>
      </main>
    </section>
  );
};

export default SubscriptionDashboard;
