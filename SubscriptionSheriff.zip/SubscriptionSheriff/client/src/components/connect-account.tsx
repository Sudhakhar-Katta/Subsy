import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ProcessingScreen from "./processing-screen";

interface ConnectAccountProps {
  userId?: number;
  onSuccess?: () => void;
}

const ConnectAccount = ({ userId, onSuccess }: ConnectAccountProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    
    const file = acceptedFiles[0];
    
    // Check if it's a CSV file
    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Read the file content
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        if (!event.target?.result) return;
        
        const csvContent = event.target.result as string;
        
        // Parse the CSV and extract transactions
        const formData = new FormData();
        formData.append('file', file);
        formData.append('userId', userId?.toString() || '1'); // Default to user 1 for demo
        
        // Send to backend for processing
        await apiRequest('POST', '/api/upload-csv', {
          userId: userId || 1,
          csvContent
        });
        
        // Invalidate subscriptions query to refresh data
        queryClient.invalidateQueries({ queryKey: [`/api/subscriptions/${userId || 1}`] });
        
        toast({
          title: "CSV processed successfully",
          description: "Your subscriptions have been detected",
        });
        
        setIsProcessing(false);
        
        // Navigate to dashboard or call success callback
        if (onSuccess) {
          onSuccess();
        } else {
          setLocation('/dashboard');
        }
      };
      
      reader.onerror = () => {
        setIsProcessing(false);
        toast({
          title: "Error reading file",
          description: "Failed to read the CSV file",
          variant: "destructive",
        });
      };
      
      reader.readAsText(file);
    } catch (error) {
      setIsProcessing(false);
      toast({
        title: "Error processing CSV",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    }
  }, [userId, toast, setLocation, onSuccess]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  if (isProcessing) {
    return <ProcessingScreen />;
  }

  return (
    <section className="min-h-screen flex flex-col items-center justify-center p-6 md:p-10 bg-white">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary mb-4">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-6 h-6 text-charcoal">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
            </svg>
          </div>
          <h1 className="text-3xl font-semibold tracking-tight">Connect Your Account</h1>
          <p className="text-gray-600 mt-2">We'll analyze your transactions to find subscriptions</p>
        </div>
        
        <div className="space-y-4">
          <div 
            {...getRootProps()} 
            className={`w-full border-2 border-dashed ${isDragActive ? 'border-primary' : 'border-gray-300'} 
            hover:border-gray-400 rounded-lg p-8 text-center cursor-pointer transition duration-200`}
          >
            <input {...getInputProps()} />
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-10 h-10 text-gray-400 mx-auto mb-4">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="17 8 12 3 7 8"/>
              <line x1="12" y1="3" x2="12" y2="15"/>
            </svg>
            <p className="text-lg font-medium">
              {isDragActive ? 'Drop the CSV file here' : 'Upload Bank Statement (CSV)'}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Drag and drop your bank statement CSV file, or click to select
            </p>
          </div>
          
          <Button 
            className="w-full bg-primary hover:bg-primary-dark text-charcoal font-medium rounded-lg px-6 py-4 transition duration-200 flex items-center justify-center gap-2"
            disabled
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-5 h-5">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
            Sync via Bank (Coming Soon)
          </Button>
          
          <div className="flex items-start mt-6 p-4 bg-gray-50 rounded-lg">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-5 h-5 text-green-600 mt-0.5 mr-3">
              <path d="M20 5H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z"/>
              <polyline points="20 21 12 13.5 4 21"/>
            </svg>
            <div>
              <p className="text-sm text-gray-600">Your data is secure and encrypted. We only analyze transaction data to find subscriptions and never store your bank credentials.</p>
              <a href="#" className="text-sm text-blue-500 hover:underline mt-1 inline-block">Learn more about our security</a>
            </div>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <Link href="/">
            <Button variant="ghost" className="text-gray-500 hover:text-gray-700 text-sm font-medium">
              &larr; Back
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ConnectAccount;
