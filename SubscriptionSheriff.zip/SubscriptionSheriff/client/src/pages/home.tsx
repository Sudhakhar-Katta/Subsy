import WelcomeScreen from "@/components/welcome-screen";

const Home = () => {
  return <WelcomeScreen />;
};

export default Home;
