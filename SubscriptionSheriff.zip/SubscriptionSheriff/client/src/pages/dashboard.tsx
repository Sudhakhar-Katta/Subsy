import SubscriptionDashboard from "@/components/subscription-dashboard";
import { useAuth } from "@/hooks/use-auth";

const Dashboard = () => {
  const { user } = useAuth();
  
  return (
    <SubscriptionDashboard 
      userId={user?.id} 
      user={user ? {
        id: user.id,
        username: user.username,
        email: user.email,
        isPremium: user.isPremium
      } : undefined} 
    />
  );
};

export default Dashboard;
