import PremiumUpgrade from "@/components/premium-upgrade";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

const Premium = () => {
  const [, setLocation] = useLocation();
  const [userId, setUserId] = useState<number | undefined>(undefined);
  
  // Check if user is authenticated
  useEffect(() => {
    // In a real app, we'd check authentication status
    // For demo purposes, use a default user
    const demoUserId = 1;
    
    setUserId(demoUserId);
    
    // In a real app, redirect to login if not authenticated
    // if (!demoUserId) {
    //   setLocation('/login');
    // }
  }, [setLocation]);
  
  // For demo purposes, we'll allow accessing the premium page without authentication
  return <PremiumUpgrade userId={userId} />;
};

export default Premium;
